import { LightningElement, api } from 'lwc';

export default class LocationDisplayUS extends LightningElement {
    @api locationData; 

}